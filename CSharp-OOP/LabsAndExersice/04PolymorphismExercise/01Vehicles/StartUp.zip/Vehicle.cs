﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01Vehicles
{
    public abstract class Vehicle
    {
        protected Vehicle(double fuelQuantity, double fuelConsumation, double airConditioner)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumation;
            AirConditionar = airConditioner;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; private set; }

        private double AirConditionar { get; set; }

        public void Drive(double distance)
        {
            double needFuel = (FuelConsumption + AirConditionar) * distance;

            if (needFuel > FuelQuantity)
            {
                throw new ArgumentException($"{GetType().Name} needs refueling");
            }

            FuelQuantity -= needFuel;
        }

        public virtual void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }

        public override string ToString()
        {
            return $"{GetType().Name}: {FuelQuantity:F2}";
        }
    }
}
