﻿using System;

namespace _01Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carInput = Console.ReadLine()
                .Split();

            string[] truckInput = Console.ReadLine()
                .Split();

            Car car = new Car(double.Parse(carInput[1]), double.Parse(carInput[2]));

            Truck truck = new Truck(double.Parse(truckInput[1]), double.Parse(truckInput[2]));

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine()
                    .Split();

                string command = input[0];
                string type = input[1];
                double parameter = double.Parse(input[2]);

                if (command == "Drive")
                {
                    try
                    {
                        if (type == nameof(Car))
                        {
                            car.Drive(parameter);
                        }
                        else
                        {
                            truck.Drive(parameter);
                        }

                        Console.WriteLine($"{type} travelled {parameter} km");
                    }
                    catch (ArgumentException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    if (type == nameof(Car))
                    {
                        car.Refuel(parameter);
                    }
                    else
                    {
                        truck.Refuel(parameter);
                    }
                }
            }

            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());
        }
    }
}
