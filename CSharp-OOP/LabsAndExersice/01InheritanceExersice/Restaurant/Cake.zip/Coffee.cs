﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Coffee : HotBeverage
    {
        private double CoffeeMilliliter = 50;
        private decimal CoffeePrice = 3.5M;

        public Coffee(string name, decimal price, double millilitres)
            : base(name, price, millilitres)
        {

        }

        public double Caffeine  { get; set; }
    }
}
