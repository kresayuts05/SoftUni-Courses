﻿using EasterRaces.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasterRaces.Repositories
{
    public abstract class Repository<T> : IRepository<T>
    {
        private List<T> models;

        public void Add(T model)
        {
            models.Add(model);
        }

        public IReadOnlyCollection<T> GetAll()
        {
            IReadOnlyCollection<T> colection = models;

            return colection;
        }

        public T GetByName(string name)
        {
            T model = models.FirstOrDefault(m => m.GetType().Name == name);

            return model;
        }

        public bool Remove(T model)
        {
            bool removed = models.Remove(model);

            return removed;
        }
    }
}
