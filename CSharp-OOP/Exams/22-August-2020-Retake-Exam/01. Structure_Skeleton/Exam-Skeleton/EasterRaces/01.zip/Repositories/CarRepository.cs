﻿using EasterRaces.Models.Cars.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace EasterRaces.Repositories
{
    public class CarRepository : Repository<ICar>
    {
    }
}
