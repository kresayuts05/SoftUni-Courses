﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> indentifianles = new List<IIdentifiable>();

            string inputStr = Console.ReadLine();

            while (inputStr.ToLower() != "end")
            {
                string[] input = inputStr.Split();

                if (input.Length == 3)
                {
                    string name = input[0];
                    int age = int.Parse(input[1]);
                    string id = input[2];

                    indentifianles.Add(new Citizen(name, age, id));
                }
                else
                {
                    string model = input[0];
                    string id = input[1];

                    indentifianles.Add(new Robot(model, id));
                }

                inputStr = Console.ReadLine();
            }

            string fakeID = Console.ReadLine();

            List<IIdentifiable> filtred = indentifianles
                .Where(x => x.Id.EndsWith(fakeID))
                .ToList();

            foreach (var item in filtred)
            {
                Console.WriteLine(item.Id);
            }
        }
    }
}
