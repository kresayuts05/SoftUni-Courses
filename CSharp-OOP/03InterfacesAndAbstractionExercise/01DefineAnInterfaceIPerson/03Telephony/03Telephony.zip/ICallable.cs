﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03Telephony
{
    interface ICallable
    {
        string Calling(string number);
    }
}
