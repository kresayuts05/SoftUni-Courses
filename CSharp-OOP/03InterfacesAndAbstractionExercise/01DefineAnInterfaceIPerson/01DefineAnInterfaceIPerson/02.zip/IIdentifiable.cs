﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
